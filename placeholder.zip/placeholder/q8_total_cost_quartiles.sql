-- For each Customer, get the CompanyName, CustomerId, and "total expenditures".
-- Output the bottom quartile of Customers, as measured by total expenditures.

-- Details:
-- Calculate expenditure using UnitPrice and Quantity (ignore Discount).
-- Compute the quartiles for each company's total expenditures using NTILE.
-- (https://www.sqlitetutorial.net/sqlite-window-functions/sqlite-ntile/)
-- The bottom quartile is the 1st quartile, order them by increasing expenditure.

-- Note that there are orders for CustomerIds that don't appear in the Customer table.
-- You should still consider these "Customers" and output them. 
-- If the CompanyName is missing, override the NULL to 'MISSING_NAME' using IFNULL.


